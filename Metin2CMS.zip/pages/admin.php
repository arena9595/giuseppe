<div class="mt2cms2-c-l">
    <div class="page-hd" style="background-image: url(<?php print $site_url; ?>images/user.png)">
        <div class="bd-c">
            <h2 class="pre-social"><?php print $a_title; ?></h2>
        </div>
    </div>
    <div class="bd-c">
        <ul class='blogroll'>
			<?php
				include 'pages/admin/'.$a_page.'.php';
			?>
        </ul>
    </div>
</div>