<?php
	//Site url - add / at the end, eg: http://metin2cms.cf/mt2/ IMPORTANT!!!
	$site_url = "http://metin2cms.cf/mt2/";
	
	//Game database
	$host = "5.206.224.101";
	$user = "root";
	$password = "Hannshanns.1";
	
	//Privileges - web_admin minim level for use admin functions
	$news_lvl = 1;
	
	//Mail settings
	$SMTPAuth = true;
	$SMTPSecure = "tls";
	$EmailHost = "giuseare95@gmail.com";
	$emailPort = 587;
	
	$email_username = "metin2cms.cf@gmail.com";//gmail account
	$email_password = "xxxxxx";//gmail password
	
	//Register
	$safebox_size = 1;